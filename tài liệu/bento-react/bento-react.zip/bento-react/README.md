# React + TypeScript + Vite

# How To Run Project
