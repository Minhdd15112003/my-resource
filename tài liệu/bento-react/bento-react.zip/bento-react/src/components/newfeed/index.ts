export { default as Newfeed } from './newfeed';
