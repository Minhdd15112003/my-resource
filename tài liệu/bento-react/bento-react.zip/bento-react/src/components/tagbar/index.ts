export { default as TagsBar } from './tagbar';
