export { default as TrendingTopicCard } from './trending-topic-card';
