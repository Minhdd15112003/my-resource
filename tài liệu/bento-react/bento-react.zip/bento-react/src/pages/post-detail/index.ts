export { default as PostDetail } from './post-detail';
