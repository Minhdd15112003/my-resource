import EventEmitter from 'eventemitter3';

const eventBus = new EventEmitter();

export default eventBus;
