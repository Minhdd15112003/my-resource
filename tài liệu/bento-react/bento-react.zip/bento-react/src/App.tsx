import AppRouter from '@routers/app-router';

// ----------------------------------------------------------------------

export default function App() {
  return (
    <>
      <AppRouter />
    </>
  );
}
